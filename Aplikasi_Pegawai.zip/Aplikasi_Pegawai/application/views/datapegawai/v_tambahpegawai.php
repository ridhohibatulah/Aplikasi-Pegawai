<section>
<a href="<?php echo site_url('Admin/tambahdatapegawai'); ?>" class="btn btn-info pull-lefth">Tambah Data Pegawai</a>	
<br/> <br>

<div class="content">>
	<h3>Info  :</h3>
<div class="box-body">
              <table colspan="2" id="example1" class="table table-bordered table-striped">


              	<tr>
              		<thead>
              			<th>nip</th>
              		</thead>
              	</tr>
              	<?php
					if(!empty($DataPegawai))
					{
						foreach($DataPegawai as $ReadDS)
						{
					?>
					<tr>
              	<td><?php echo $ReadDS->nip; ?></td>
              	</tr>
              	<?php		
						}
					}
					?>
              	</table>
              </div>

</section>