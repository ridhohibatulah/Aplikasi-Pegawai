    <section class="content-header">
      <h1>
        <i class="glyphicon glyphicon-plus"></i>
        TAMBAH DATA PEGAWAI
      </h1>
    </section><br>


 <section class="content">
 <div class="col-lg">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah Data Pegawai</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" action="<?php echo site_url('Welcome/AddDataPegawai'); ?>" method="post">
              
              <div class="box-body">
                <div class="form-group">
                  <label for="inputnip" class="col-sm-2 control-label">NIP</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputnip" name="nip">
                  </div>
                </div>
                
                          <div class="form-group">
                            <label for="inputgelar_awal" class="col-sm-2 control-label">Gelar Awal</label>
                            <div class="col-sm-2">
                              <input type="text" class="form-control" id="inputgelar_awal" name="gelar_awal">
                            </div>
                                  <label for="inputnama" class="col-sm-1 control-label">Nama </label>
                                  <div class="col-sm-3">
                                    <input type="text" class="form-control" id="inputnama" name="nama">
                                  </div>
                            <label for="inputgelar_awal" class="col-sm-2 control-label">Gelar Akhir</label>
                            <div class="col-sm-2">
                              <input type="text" class="form-control" id="inputgelar_akhir" name="gelar_akhir">
                            </div>
                          </div>
                
                <div class="form-group">
                  <label for="inputtempat_lahir" class="col-sm-2 control-label">Tempat Lahir</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputtempat_lahir" name="tempat_lahir">
                  </div>
                </div>

                 <div class="form-group">
                  <label for="inputagama" class="col-sm-2 control-label">Agama</label>
                  <div class="col-sm-10">
                    <select id="agama" name="agama">
                        <option value="islam">Islam</option>
                        <option value="kristen">Kristen</option>
                        <option value="hindu">Hindu</option>
                        <option value="katolik">Katolik</option>
                        <option value="buddha">Buddha</option>
                        <option value="kong hu cu">Kong Hu Cu</option>
                      </select> 
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputpangkat" class="col-sm-2 control-label">Pangkat</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputpangkat" name="pangkat">
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputjabatan" class="col-sm-2 control-label">Jabatan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputjabatan" name="jabatan">
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputunit_bidang" class="col-sm-2 control-label">Unit Bidang</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputunit_bidang" name="unit_bidang">
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputstatus_pegawai" class="col-sm-2 control-label">Status Pegawai</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputstatus_pegawai" name="status_pegawai">
                  </div>
                </div>
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" name="simpan" value="Simpan" data-toggle="modal" data-target="#modal-tambahdata" class="btn btn-info pull-right">Simpan</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
        </div>
      </section>