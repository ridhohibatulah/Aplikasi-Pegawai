    <section class="content-header">
      <h1><i class="fa fa-dashboard">  Dashboard
      </i></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dasboard</li>
      </ol>
    </section>
<br>
    <section class="content">
      
      <div class="col-lg-3 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3>Add</h3>

              <p>Data Pegawai</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo site_url('Welcome/DataPegawai'); ?>" class="small-box-footer">add <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

<div class="col-lg-3 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Cuti</h3>

              <p>Pengajuan Cuti</p>
            </div>
            <div class="icon">
              <i class="ion ion-add"></i>
            </div>
            <a href="<?php echo site_url('Welcome/PengajuanCuti'); ?>" class="small-box-footer">Pengajuan <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>    </section>