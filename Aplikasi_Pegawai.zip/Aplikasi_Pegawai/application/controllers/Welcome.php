<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
	parent::__construct();
	$this->load->model('MSudi');
	}

	public function index()
	{
		if($this->session->userdata('Login'))
		{
			$data['content']='tampil/VBlank';
			$this->load->view('tampil/VBackend',$data);
		}
		else
		{
			 redirect(site_url('Login'));
		}

	}

	public function DataPegawai()
	{

		

		if($this->uri->segment(4)=='view')
		{
			$nip=$this->uri->segment(3);
			$tampil=$this->MSudi->GetDataWhere('tbl_pegawai','nip',$nip)->row();
			$data['detail']['nip']= $tampil->nip;
			$data['detail']['gelar_awal']= $tampil->gelar_awal;
            		$data['detail']['nama']= $tampil->nama;
            		$data['detail']['gelar_akhir']= $tampil->gelar_akhir;
            		$data['detail']['tempat_lahir']= $tampil->tempat_lahir;
            		$data['detail']['agama']= $tampil->agama;
            		$data['detail']['pangkat']= $tampil->pangkat;
            		$data['detail']['jabatan']= $tampil->jabatan;
            		$data['detail']['unit_bidang']= $tampil->unit_bidang;
            		$data['detail']['status_pegawai']= $tampil->status_pegawai;
			$data['content']='datapegawai/v_editdatapegawai';
		}
		else
		{	
			$data['DataPegawai']=$this->MSudi->GetData('tbl_pegawai');
			$data['content']='datapegawai/v_datapegawai';
		}

		$this->load->view('tampil/VBackend',$data);
	}


	public function tambahdatapegawai()
	{
		$data['content']='datapegawai/v_tambahdatapegawai';
		$this->load->view('tampil/VBackend',$data);
	}

	public function AddDataPegawai()
	{
		 $add['nip']=$this->input->post('nip');
         	 $add['gelar_awal']= $this->input->post('gelar_awal');
         	 $add['nama']= $this->input->post('nama');  
         	 $add['gelar_akhir']= $this->input->post('gelar_akhir');
         	 $add['tempat_lahir']= $this->input->post('tempat_lahir');
         	 $add['agama']= $this->input->post('agama');
         	 $add['pangkat']= $this->input->post('pangkat');
         	 $add['jabatan']= $this->input->post('jabatan');
         	 $add['unit_bidang']= $this->input->post('unit_bidang');
         	 $add['status_pegawai']= $this->input->post('status_pegawai');
        	 $this->MSudi->AddData('tbl_pegawai',$add) ;
        	 $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"><h4 class="alert-heading">Data Berhasil Ditambahkan</h4><p></p></div>');
        	 redirect(site_url('Welcome/DataPegawai'));
	}





	public function UpdateDataPegawai()
	{
		 $nip=$this->input->post('nip');
		 	 $update['gelar_awal']= $this->input->post('gelar_awal');
		 	 $update['nama']= $this->input->post('nama');
         	 $update['gelar_akhir']= $this->input->post('gelar_akhir');
         	 $update['tempat_lahir']= $this->input->post('tempat_lahir');
         	 $update['agama']= $this->input->post('agama');
         	 $update['pangkat']= $this->input->post('pangkat');
         	 $update['jabatan']= $this->input->post('jabatan');
         	 $update['unit_bidang']= $this->input->post('unit_bidang');
         	 $update['status_pegawai']= $this->input->post('status_pegawai');
          	 $this->MSudi->UpdateData('tbl_pegawai','nip',$nip,$update);
          	 $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"><h4 class="alert-heading">Data Berhasil Ditambahkan</h4><p></p></div>');
		 redirect(site_url('Welcome/DataPegawai'));
	}



	public function DeleteDataPegawai()
	{
		 $nip=$this->uri->segment('3');
        	 $this->MSudi->DeleteData('tbl_pegawai','nip',$nip);
        	 $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"><h4 class="alert-heading">Data Berhasil Ditambahkan</h4><p></p></div>');
        	 redirect(site_url('Welcome/DataPegawai'));
	}


//////////////////////////////// Datapensiun////////////////////////////////////////////////////////////////////////////////////////////////

	public function DataPensiun()
	{		
		{	
			$data['DataPegawai']=$this->MSudi->GetData('tbl_pegawai');
			$data['content']='datapegawai/VPensiun';
		}


		$this->load->view('tampil/VBackend',$data);
	}

	public function DetailPegawai()
	{
		$nip=$this->uri->segment(3);
			$tampil=$this->MSudi->GetDataWhere('tbl_pegawai','nip',$nip)->row();
			$data['detail']['nip']= $tampil->nip;
			$data['detail']['gelar_awal']= $tampil->gelar_awal;
            		$data['detail']['nama']= $tampil->nama;
            		$data['detail']['gelar_akhir']= $tampil->gelar_akhir;
            		$data['detail']['tempat_lahir']= $tampil->tempat_lahir;
            		$data['detail']['agama']= $tampil->agama;
            		$data['detail']['pangkat']= $tampil->pangkat;
            		$data['detail']['jabatan']= $tampil->jabatan;
            		$data['detail']['unit_bidang']= $tampil->unit_bidang;
            		$data['detail']['status_pegawai']= $tampil->status_pegawai;
			$data['content']='datapegawai/v_detailpegawai';
			$this->load->view('tampil/VBackend',$data);
	}
	

//////////////////////////////// Datapensiun////////////////////////////////////////////////////////////////////////////////////////////////

	public function PengajuanCuti()
	{
		if($this->uri->segment(4)=='view')
		{
			$id_cuti=$this->uri->segment(3);
			$tampil=$this->MSudi->GetDataWhere('tbl_cuti','id_cuti',$id_cuti)->row();
			$data['detail']['id_cuti']= $tampil->id_cuti;
			$data['detail']['nip']= $tampil->nip;			
            		$data['detail']['nama']= $tampil->nama;
            		$data['detail']['tgl_pengajuan']= $tampil->tgl_pengajuan;
            		$data['detail']['tgl_mulai']= $tampil->tgl_mulai;
            		$data['detail']['tgl_akhir']= $tampil->tgl_akhir;
            		$data['detail']['jenis_cuti']= $tampil->jenis_cuti;
            		$data['detail']['alasan']= $tampil->alasan;
            		$data['detail']['persetujuan']= $tampil->persetujuan;
			$data['content']='cuti/v_editPengajuanCuti';
		}
		else
		{	
			$data['PengajuanCuti']=$this->MSudi->GetData('tbl_cuti');
			$data['content']='cuti/v_datapengajuan';
		}


		$this->load->view('tampil/VBackend',$data);
	}

	
	public function PersetujuanPengajuanCuti()
	{
		$id_cuti=$this->uri->segment(3);
			$tampil=$this->MSudi->GetDataWhere('tbl_cuti','id_cuti',$id_cuti)->row();
			$data['detail']['id_cuti']= $tampil->id_cuti;
			$data['detail']['nip']= $tampil->nip;			
            		$data['detail']['nama']= $tampil->nama;
            		$data['detail']['tgl_pengajuan']= $tampil->tgl_pengajuan;
            		$data['detail']['tgl_mulai']= $tampil->tgl_mulai;
            		$data['detail']['tgl_akhir']= $tampil->tgl_akhir;
            		$data['detail']['jenis_cuti']= $tampil->jenis_cuti;
            		$data['detail']['alasan']= $tampil->alasan;
            		$data['detail']['persetujuan']= $tampil->persetujuan;
			$data['content']='cuti/v_editPersetujuanPengajuanCuti';
			$this->load->view('tampil/VBackend',$data);
	}

	public function VPengajuanCuti()
	{
		$data['content']='cuti/v_pengajuancuti';
		$this->load->view('tampil/VBackend',$data);
	}

	public function AddPengajuanCuti()
	{
		 $add['nip']=$this->input->post('nip');
         	 $add['nama']= $this->input->post('nama');  
         	 $add['tgl_pengajuan']= $this->input->post('tgl_pengajuan');
         	 $add['tgl_mulai']= $this->input->post('tgl_mulai');
         	 $add['tgl_akhir']= $this->input->post('tgl_akhir');
         	 $add['jenis_cuti']= $this->input->post('jenis_cuti');
         	 $add['alasan']= $this->input->post('alasan');
         	 $add['persetujuan']= $this->input->post('persetujuan');
        	 $this->MSudi->AddData('tbl_cuti',$add);
        	 redirect(site_url('Welcome/PengajuanCuti'));
	}
	public function UpdatePengajuanCuti()
	{
		 $id_cuti=$this->input->post('id_cuti');
		 	 $update['nip']= $this->input->post('nip');
		 	 $update['nama']= $this->input->post('nama');
         	 $update['tgl_pengajuan']= $this->input->post('tgl_pengajuan');
         	 $update['tgl_mulai']= $this->input->post('tgl_mulai');
         	 $update['tgl_akhir']= $this->input->post('tgl_akhir');
         	 $update['jenis_cuti']= $this->input->post('jenis_cuti');
         	 $update['alasan']= $this->input->post('alasan');
         	 $update['persetujuan']= $this->input->post('persetujuan');
          	 $this->MSudi->UpdateData('tbl_cuti','id_cuti',$id_cuti,$update);
          	 $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"><h4 class="alert-heading">Data Berhasil Ditambahkan</h4><p></p></div>');
		 redirect(site_url('Welcome/PengajuanCuti'));
	}

	public function DataCuti()
	{
			$data['PengajuanCuti']=$this->MSudi->GetData('tbl_cuti');
			$data['content']='cuti/v_datacuti';
	
		$this->load->view('tampil/VBackend',$data);
	}

	public function DeletePengajuanCuti()
	{
		 $id_cuti=$this->uri->segment('3');
        	 $this->MSudi->DeleteData('tbl_cuti','id_cuti',$id_cuti);
        	 $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"><h4 class="alert-heading">Data Berhasil Ditambahkan</h4><p></p></div>');
        	 redirect(site_url('Welcome/DataCuti'));
	}


	public function Logout()
	{
		$this->load->library('session');
		$this->session->unset_userdata('Login');
		redirect(site_url('Login'));
	}

}